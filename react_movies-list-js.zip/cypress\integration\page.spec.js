describe('Page', () => {
  it('should be visitable', () => {
    cy.visit('/');
  });
});
