import MovieCard from '../MovieCard';

function MovieList({ movies }) {
  return (
    <div className="movies" data-cy="movies-list">
      {movies.map(movie => (
        <MovieCard key={movie.imdbId} movie={movie} />
      ))}
    </div>
  );
}

export default MovieList;
